// backend/src/socket/handler.js
var jwt = require('jsonwebtoken');
var uuid = require('uuid');
var xss = require('xss');
var constants = require('../../../shared/constants');

var voiceRooms = {};
var onlineUsers = {};
var typingTimeouts = {};

function setupSocket(io, db, secret) {

  io.use(function(socket, next) {
    var token = socket.handshake.query.token;
    if (!token) return next(new Error('Authentication required'));
    try {
      var decoded = jwt.verify(token, secret);
      db.users.findOne({ _id: decoded.userId }).then(function(user) {
        if (!user) return next(new Error('User not found'));
        socket.user = { id: user._id, username: user.username, avatar: user.avatar };
        next();
      }).catch(function() { next(new Error('Auth error')); });
    } catch (err) { next(new Error('Invalid token')); }
  });

  io.on('connection', function(socket) {
    var user = socket.user;
    console.log('[Socket] Connected: ' + user.username);
    onlineUsers[socket.id] = { userId: user.id, username: user.username };
    db.users.update({ _id: user.id }, { $set: { status: 'online' } });
    socket.join('user:' + user.id);
    io.emit('presence-update', { userId: user.id, status: 'online' });

    socket.on('join-server', function(data) {
      if (!data || !data.serverId) return;
      db.members.findOne({ serverId: data.serverId, userId: user.id }).then(function(m) {
        if (m) socket.join('server:' + data.serverId);
      });
    });

    socket.on('join-channel', function(data) {
      if (!data || !data.channelId) return;
      db.channels.findOne({ _id: data.channelId }).then(function(ch) {
        if (!ch) return;
        db.members.findOne({ serverId: ch.serverId, userId: user.id }).then(function(m) {
          if (m) socket.join('channel:' + data.channelId);
        });
      });
    });

    socket.on('leave-channel', function(data) {
      if (data && data.channelId) socket.leave('channel:' + data.channelId);
    });

    socket.on('send-message', function(data) {
      if (!data || !data.channelId || !data.content) return;
      var content = xss(data.content.substring(0, constants.LIMITS.MESSAGE_MAX_LENGTH));
      if (!content.trim()) return;

      db.channels.findOne({ _id: data.channelId }).then(function(ch) {
        if (!ch) return null;
        return db.members.findOne({ serverId: ch.serverId, userId: user.id });
      }).then(function(member) {
        if (!member) return;
        var msgId = uuid.v4();
        var now = new Date().toISOString();
        return db.messages.insert({
          _id: msgId, channelId: data.channelId, userId: user.id,
          content: content, attachments: data.attachments || null, createdAt: now
        }).then(function() {
          io.to('channel:' + data.channelId).emit('new-message', {
            id: msgId, channel_id: data.channelId, user_id: user.id,
            username: user.username, avatar: user.avatar,
            content: content, attachments: data.attachments || null, created_at: now
          });
        });
      }).catch(function(err) { console.error('[Socket] msg error:', err); });
    });

    socket.on('typing', function(data) {
      if (!data || !data.channelId) return;
      var key = data.channelId + ':' + user.id;
      if (typingTimeouts[key]) return;
      typingTimeouts[key] = setTimeout(function() { delete typingTimeouts[key]; }, 3000);
      socket.to('channel:' + data.channelId).emit('user-typing', {
        channelId: data.channelId, userId: user.id, username: user.username
      });
    });

    socket.on('join-voice', function(data) {
      if (!data || !data.channelId) return;
      if (!voiceRooms[data.channelId]) voiceRooms[data.channelId] = [];
      var already = voiceRooms[data.channelId].some(function(u) { return u.userId === user.id; });
      if (!already) voiceRooms[data.channelId].push({ userId: user.id, username: user.username, socketId: socket.id });
      emitVoiceState(db, io, data.channelId);
    });

    socket.on('leave-voice', function(data) {
      if (!data || !data.channelId) return;
      removeFromVoice(data.channelId, user.id);
      emitVoiceState(db, io, data.channelId);
    });

    socket.on('disconnect', function() {
      console.log('[Socket] Disconnected: ' + user.username);
      delete onlineUsers[socket.id];
      var stillOnline = Object.keys(onlineUsers).some(function(sid) { return onlineUsers[sid].userId === user.id; });
      if (!stillOnline) {
        db.users.update({ _id: user.id }, { $set: { status: 'offline' } });
        io.emit('presence-update', { userId: user.id, status: 'offline' });
      }
      Object.keys(voiceRooms).forEach(function(chId) {
        var before = (voiceRooms[chId] || []).length;
        removeFromVoice(chId, user.id);
        if ((voiceRooms[chId] || []).length !== before) emitVoiceState(db, io, chId);
      });
    });
  });
}

function removeFromVoice(channelId, userId) {
  if (!voiceRooms[channelId]) return;
  voiceRooms[channelId] = voiceRooms[channelId].filter(function(u) { return u.userId !== userId; });
  if (voiceRooms[channelId].length === 0) delete voiceRooms[channelId];
}

function emitVoiceState(db, io, channelId) {
  var users = (voiceRooms[channelId] || []).map(function(u) { return { userId: u.userId, username: u.username }; });
  db.channels.findOne({ _id: channelId }).then(function(ch) {
    if (ch) io.to('server:' + ch.serverId).emit('voice-state', { channelId: channelId, users: users });
  });
}

module.exports = setupSocket;
