// backend/src/middleware/auth.js
var jwt = require('jsonwebtoken');

function authMiddleware(req, res, next) {
  var secret = req.app.get('jwt_secret');
  var token = null;

  var authHeader = req.headers.authorization;
  if (authHeader && authHeader.indexOf('Bearer ') === 0) {
    token = authHeader.substring(7);
  } else if (req.headers.cookie) {
    var cookies = req.headers.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) {
      var c = cookies[i].trim();
      if (c.indexOf('token=') === 0) { token = c.substring(6); break; }
    }
  }

  if (!token) return res.status(401).json({ error: 'Authentication required' });

  try {
    var decoded = jwt.verify(token, secret);
    var db = req.app.get('db');
    db.users.findOne({ _id: decoded.userId }).then(function(user) {
      if (!user) return res.status(401).json({ error: 'User not found' });
      req.user = {
        id: user._id,
        username: user.username,
        email: user.email,
        avatar: user.avatar,
        status: user.status
      };
      req.token = token;
      next();
    }).catch(function() {
      res.status(401).json({ error: 'Auth error' });
    });
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

function requireRole(roles) {
  return function(req, res, next) {
    var db = req.app.get('db');
    var serverId = req.params.id || req.params.serverId;
    if (!serverId) return res.status(400).json({ error: 'Server ID required' });

    db.members.findOne({ serverId: serverId, userId: req.user.id }).then(function(member) {
      if (!member) return res.status(403).json({ error: 'Not a member of this server' });
      if (roles.indexOf(member.role) === -1) return res.status(403).json({ error: 'Insufficient permissions' });
      req.memberRole = member.role;
      next();
    }).catch(function() {
      res.status(500).json({ error: 'Server error' });
    });
  };
}

module.exports = { authMiddleware: authMiddleware, requireRole: requireRole };
