// backend/src/routes/auth.js
var express = require('express');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
var uuid = require('uuid');
var rateLimit = require('express-rate-limit');
var xss = require('xss');
var router = express.Router();
var auth = require('../middleware/auth');
var LIMITS = require('../../../shared/constants').LIMITS;

var loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 10, message: { error: 'Too many login attempts' } });

// POST /api/auth/register
router.post('/register', function(req, res) {
  var db = req.app.get('db');
  var secret = req.app.get('jwt_secret');
  var username = xss((req.body.username || '').trim());
  var email = (req.body.email || '').trim().toLowerCase();
  var password = req.body.password || '';

  if (!username || username.length < LIMITS.USERNAME_MIN || username.length > LIMITS.USERNAME_MAX) {
    return res.status(400).json({ error: 'Username must be ' + LIMITS.USERNAME_MIN + '-' + LIMITS.USERNAME_MAX + ' chars' });
  }
  if (!email || !email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
    return res.status(400).json({ error: 'Invalid email' });
  }
  if (!password || password.length < LIMITS.PASSWORD_MIN) {
    return res.status(400).json({ error: 'Password must be at least ' + LIMITS.PASSWORD_MIN + ' characters' });
  }

  db.users.findOne({ $or: [{ email: email }, { username: username }] }).then(function(existing) {
    if (existing) return res.status(409).json({ error: 'Username or email already taken' });

    var id = uuid.v4();
    var hash = bcrypt.hashSync(password, 10);

    return db.users.insert({
      _id: id, username: username, email: email, passwordHash: hash,
      avatar: null, status: 'online', createdAt: new Date().toISOString()
    }).then(function(user) {
      var token = jwt.sign({ userId: id }, secret, { expiresIn: '7d' });
      res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000, sameSite: 'lax' });
      res.json({ token: token, user: { id: id, username: username, email: email, avatar: null, status: 'online' } });
    });
  }).catch(function(err) {
    res.status(500).json({ error: 'Registration failed' });
  });
});

// POST /api/auth/login
router.post('/login', loginLimiter, function(req, res) {
  var db = req.app.get('db');
  var secret = req.app.get('jwt_secret');
  var email = (req.body.email || '').trim().toLowerCase();
  var password = req.body.password || '';

  db.users.findOne({ email: email }).then(function(user) {
    if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    db.users.update({ _id: user._id }, { $set: { status: 'online' } });

    var token = jwt.sign({ userId: user._id }, secret, { expiresIn: '7d' });
    res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000, sameSite: 'lax' });
    res.json({
      token: token,
      user: { id: user._id, username: user.username, email: user.email, avatar: user.avatar, status: 'online' }
    });
  }).catch(function() {
    res.status(500).json({ error: 'Login failed' });
  });
});

// POST /api/auth/logout
router.post('/logout', auth.authMiddleware, function(req, res) {
  var db = req.app.get('db');
  db.users.update({ _id: req.user.id }, { $set: { status: 'offline' } });
  res.clearCookie('token');
  res.json({ success: true });
});

// GET /api/auth/me
router.get('/me', auth.authMiddleware, function(req, res) {
  res.json({ user: req.user });
});

module.exports = router;
