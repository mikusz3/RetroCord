// backend/src/routes/upload.js
var express = require('express');
var multer = require('multer');
var path = require('path');
var uuid = require('uuid');
var router = express.Router();
var auth = require('../middleware/auth');
var constants = require('../../../shared/constants');

var uploadsDir = path.join(__dirname, '..', '..', 'uploads');
var fs = require('fs');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

var storage = multer.diskStorage({
  destination: function(req, file, cb) { cb(null, uploadsDir); },
  filename: function(req, file, cb) {
    var ext = path.extname(file.originalname).toLowerCase();
    cb(null, uuid.v4() + ext);
  }
});

var fileFilter = function(req, file, cb) {
  var ext = path.extname(file.originalname).toLowerCase();
  if (constants.ALLOWED_EXTENSIONS.indexOf(ext) === -1) return cb(new Error('File type not allowed'), false);
  cb(null, true);
};

var upload = multer({ storage: storage, fileFilter: fileFilter, limits: { fileSize: constants.LIMITS.FILE_MAX_SIZE } });

router.post('/', auth.authMiddleware, upload.single('file'), function(req, res) {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  res.json({ url: '/files/' + req.file.filename, filename: req.file.originalname, size: req.file.size, mimetype: req.file.mimetype });
});

router.use(function(err, req, res, next) {
  if (err && err.code === 'LIMIT_FILE_SIZE') return res.status(400).json({ error: 'File too large (max 5MB)' });
  if (err) return res.status(400).json({ error: err.message });
  next();
});

module.exports = router;
