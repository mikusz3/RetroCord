// backend/src/routes/messages.js
var express = require('express');
var router = express.Router();
var auth = require('../middleware/auth');

// GET /api/channels/:channelId/messages
router.get('/:channelId/messages', auth.authMiddleware, function(req, res) {
  var db = req.app.get('db');
  var channelId = req.params.channelId;
  var before = req.query.before || null;
  var limit = Math.min(parseInt(req.query.limit) || 50, 100);

  db.channels.findOne({ _id: channelId }).then(function(channel) {
    if (!channel) return res.status(404).json({ error: 'Channel not found' });
    return db.members.findOne({ serverId: channel.serverId, userId: req.user.id }).then(function(member) {
      if (!member) return res.status(403).json({ error: 'Not a member' });

      var query = { channelId: channelId };
      if (before) query.createdAt = { $lt: before };

      return db.messages.find(query).sort({ createdAt: -1 }).limit(limit).exec();
    });
  }).then(function(messages) {
    if (!messages) return;
    // We need to attach usernames - gather unique user IDs
    var userIds = [];
    messages.forEach(function(m) { if (userIds.indexOf(m.userId) === -1) userIds.push(m.userId); });

    return db.users.find({ _id: { $in: userIds } }).then(function(users) {
      var userMap = {};
      users.forEach(function(u) { userMap[u._id] = u; });

      var result = messages.map(function(m) {
        var u = userMap[m.userId] || {};
        return {
          id: m._id, channel_id: m.channelId, user_id: m.userId,
          username: u.username || 'Unknown', avatar: u.avatar || null,
          content: m.content, attachments: m.attachments,
          created_at: m.createdAt
        };
      });

      result.reverse(); // Chronological order
      res.json({ messages: result });
    });
  }).catch(function(err) {
    res.status(500).json({ error: 'Failed to load messages' });
  });
});

// DELETE /api/channels/messages/:id
router.delete('/messages/:id', auth.authMiddleware, function(req, res) {
  var db = req.app.get('db');

  db.messages.findOne({ _id: req.params.id }).then(function(message) {
    if (!message) return res.status(404).json({ error: 'Message not found' });

    return db.channels.findOne({ _id: message.channelId }).then(function(channel) {
      if (!channel) return res.status(404).json({ error: 'Channel not found' });

      // Check perms
      var canDelete = message.userId === req.user.id;
      if (canDelete) return doDelete(message, channel);

      return db.members.findOne({ serverId: channel.serverId, userId: req.user.id }).then(function(member) {
        if (member && (member.role === 'owner' || member.role === 'admin')) {
          return doDelete(message, channel);
        }
        return res.status(403).json({ error: 'Cannot delete this message' });
      });
    });
  }).catch(function() {
    res.status(500).json({ error: 'Delete failed' });
  });

  function doDelete(message, channel) {
    return db.messages.remove({ _id: message._id }).then(function() {
      var io = req.app.get('io');
      io.to('channel:' + message.channelId).emit('message-deleted', { messageId: message._id, channelId: message.channelId });
      res.json({ success: true });
    });
  }
});

module.exports = router;
