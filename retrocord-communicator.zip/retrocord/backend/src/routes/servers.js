// backend/src/routes/servers.js
var express = require('express');
var uuid = require('uuid');
var xss = require('xss');
var router = express.Router();
var auth = require('../middleware/auth');

// POST /api/servers - Create
router.post('/', auth.authMiddleware, function(req, res) {
  var db = req.app.get('db');
  var name = xss((req.body.name || '').trim());
  if (!name || name.length > 100) return res.status(400).json({ error: 'Server name required (max 100 chars)' });

  var id = uuid.v4();
  var inviteCode = Math.random().toString(36).substring(2, 8).toUpperCase();

  var server = {
    _id: id, name: name, icon: null, ownerId: req.user.id,
    inviteCode: inviteCode, createdAt: new Date().toISOString()
  };

  db.servers.insert(server).then(function() {
    return db.members.insert({ _id: uuid.v4(), serverId: id, userId: req.user.id, role: 'owner', joinedAt: new Date().toISOString() });
  }).then(function() {
    var channelId = uuid.v4();
    return db.channels.insert({ _id: channelId, serverId: id, name: 'general', type: 'text', position: 0, createdAt: new Date().toISOString() })
      .then(function() { return channelId; });
  }).then(function(channelId) {
    res.json({ server: { id: id, name: name, icon: null, ownerId: req.user.id, inviteCode: inviteCode, my_role: 'owner' }, defaultChannel: channelId });
  }).catch(function(err) {
    res.status(500).json({ error: 'Failed to create server' });
  });
});

// GET /api/servers - List user's servers
router.get('/', auth.authMiddleware, function(req, res) {
  var db = req.app.get('db');
  db.members.find({ userId: req.user.id }).then(function(memberships) {
    var serverIds = memberships.map(function(m) { return m.serverId; });
    var roleMap = {};
    memberships.forEach(function(m) { roleMap[m.serverId] = m.role; });

    return db.servers.find({ _id: { $in: serverIds } }).then(function(servers) {
      var result = servers.map(function(s) {
        return { id: s._id, name: s.name, icon: s.icon, ownerId: s.ownerId, inviteCode: s.inviteCode, my_role: roleMap[s._id] || 'member' };
      });
      res.json({ servers: result });
    });
  }).catch(function() {
    res.status(500).json({ error: 'Failed to load servers' });
  });
});

// GET /api/servers/:id
router.get('/:id', auth.authMiddleware, function(req, res) {
  var db = req.app.get('db');
  Promise.all([
    db.servers.findOne({ _id: req.params.id }),
    db.members.findOne({ serverId: req.params.id, userId: req.user.id })
  ]).then(function(results) {
    var server = results[0], member = results[1];
    if (!server) return res.status(404).json({ error: 'Server not found' });
    if (!member) return res.status(403).json({ error: 'Not a member' });
    res.json({ server: { id: server._id, name: server.name, icon: server.icon, inviteCode: server.inviteCode, ownerId: server.ownerId }, role: member.role });
  });
});

// POST /api/servers/join
router.post('/join', auth.authMiddleware, function(req, res) {
  var db = req.app.get('db');
  var inviteCode = (req.body.inviteCode || '').trim().toUpperCase();
  if (!inviteCode) return res.status(400).json({ error: 'Invite code required' });

  db.servers.findOne({ inviteCode: inviteCode }).then(function(server) {
    if (!server) return res.status(404).json({ error: 'Invalid invite code' });

    return db.members.findOne({ serverId: server._id, userId: req.user.id }).then(function(existing) {
      if (existing) return res.json({ server: { id: server._id, name: server.name, icon: server.icon, ownerId: server.ownerId, inviteCode: server.inviteCode, my_role: existing.role }, message: 'Already a member' });

      return db.members.insert({ _id: uuid.v4(), serverId: server._id, userId: req.user.id, role: 'member', joinedAt: new Date().toISOString() }).then(function() {
        var io = req.app.get('io');
        io.to('server:' + server._id).emit('member-joined', { serverId: server._id, user: { id: req.user.id, username: req.user.username, avatar: req.user.avatar } });
        res.json({ server: { id: server._id, name: server.name, icon: server.icon, ownerId: server.ownerId, inviteCode: server.inviteCode, my_role: 'member' } });
      });
    });
  }).catch(function() {
    res.status(500).json({ error: 'Failed to join' });
  });
});

// POST /api/servers/:id/invite
router.post('/:id/invite', auth.authMiddleware, auth.requireRole(['owner', 'admin']), function(req, res) {
  var db = req.app.get('db');
  var newCode = Math.random().toString(36).substring(2, 8).toUpperCase();
  db.servers.update({ _id: req.params.id }, { $set: { inviteCode: newCode } }).then(function() {
    res.json({ inviteCode: newCode });
  });
});

// GET /api/servers/:id/members
router.get('/:id/members', auth.authMiddleware, function(req, res) {
  var db = req.app.get('db');
  db.members.find({ serverId: req.params.id }).then(function(memberships) {
    var userIds = memberships.map(function(m) { return m.userId; });
    var roleMap = {};
    memberships.forEach(function(m) { roleMap[m.userId] = m.role; });

    return db.users.find({ _id: { $in: userIds } }).then(function(users) {
      var result = users.map(function(u) {
        return { id: u._id, username: u.username, avatar: u.avatar, status: u.status, role: roleMap[u._id] || 'member' };
      });
      // Sort: owners first, then admins, then members
      var order = { owner: 0, admin: 1, member: 2 };
      result.sort(function(a, b) { return (order[a.role] || 2) - (order[b.role] || 2); });
      res.json({ members: result });
    });
  }).catch(function() {
    res.status(500).json({ error: 'Failed to load members' });
  });
});

// DELETE /api/servers/:id
router.delete('/:id', auth.authMiddleware, auth.requireRole(['owner']), function(req, res) {
  var db = req.app.get('db');
  var id = req.params.id;
  // Cascade delete
  Promise.all([
    db.channels.find({ serverId: id }).then(function(chs) {
      var chIds = chs.map(function(c) { return c._id; });
      return db.messages.remove({ channelId: { $in: chIds } }, { multi: true });
    }),
    db.channels.remove({ serverId: id }, { multi: true }),
    db.members.remove({ serverId: id }, { multi: true }),
    db.servers.remove({ _id: id })
  ]).then(function() {
    var io = req.app.get('io');
    io.to('server:' + id).emit('server-deleted', { serverId: id });
    res.json({ success: true });
  });
});

module.exports = router;
