// backend/src/routes/moderation.js
var express = require('express');
var router = express.Router();
var auth = require('../middleware/auth');

// POST /api/servers/:id/kick
router.post('/:id/kick', auth.authMiddleware, auth.requireRole(['owner', 'admin']), function(req, res) {
  var db = req.app.get('db');
  var userId = req.body.userId;
  if (!userId) return res.status(400).json({ error: 'userId required' });

  db.servers.findOne({ _id: req.params.id }).then(function(server) {
    if (!server) return res.status(404).json({ error: 'Server not found' });
    if (server.ownerId === userId) return res.status(403).json({ error: 'Cannot kick the server owner' });

    return db.members.findOne({ serverId: req.params.id, userId: userId }).then(function(target) {
      if (!target) return res.status(404).json({ error: 'User not a member' });
      if (req.memberRole === 'admin' && target.role === 'admin') {
        return res.status(403).json({ error: 'Admins cannot kick other admins' });
      }

      return db.members.remove({ serverId: req.params.id, userId: userId }).then(function() {
        var io = req.app.get('io');
        io.to('server:' + req.params.id).emit('member-left', { serverId: req.params.id, userId: userId, kicked: true });
        io.to('user:' + userId).emit('kicked-from-server', { serverId: req.params.id });
        res.json({ success: true });
      });
    });
  }).catch(function() {
    res.status(500).json({ error: 'Kick failed' });
  });
});

// POST /api/servers/:id/role
router.post('/:id/role', auth.authMiddleware, auth.requireRole(['owner']), function(req, res) {
  var db = req.app.get('db');
  var userId = req.body.userId;
  var role = req.body.role;

  if (!userId || !role) return res.status(400).json({ error: 'userId and role required' });
  if (['admin', 'member'].indexOf(role) === -1) return res.status(400).json({ error: 'Role must be admin or member' });

  db.servers.findOne({ _id: req.params.id }).then(function(server) {
    if (!server) return res.status(404).json({ error: 'Server not found' });
    if (server.ownerId === userId) return res.status(403).json({ error: 'Cannot change owner role' });

    return db.members.update({ serverId: req.params.id, userId: userId }, { $set: { role: role } }).then(function() {
      var io = req.app.get('io');
      io.to('server:' + req.params.id).emit('member-role-changed', { serverId: req.params.id, userId: userId, role: role });
      res.json({ success: true });
    });
  }).catch(function() {
    res.status(500).json({ error: 'Role update failed' });
  });
});

module.exports = router;
