// backend/src/routes/channels.js
var express = require('express');
var uuid = require('uuid');
var xss = require('xss');
var router = express.Router();
var auth = require('../middleware/auth');

// GET /api/servers/:id/channels
router.get('/:id/channels', auth.authMiddleware, function(req, res) {
  var db = req.app.get('db');
  db.members.findOne({ serverId: req.params.id, userId: req.user.id }).then(function(member) {
    if (!member) return res.status(403).json({ error: 'Not a member' });
    return db.channels.find({ serverId: req.params.id }).sort({ position: 1, createdAt: 1 }).exec();
  }).then(function(channels) {
    if (!channels) return;
    var result = channels.map(function(c) {
      return { id: c._id, server_id: c.serverId, name: c.name, type: c.type, position: c.position };
    });
    res.json({ channels: result });
  }).catch(function() {
    res.status(500).json({ error: 'Failed to load channels' });
  });
});

// POST /api/servers/:id/channels
router.post('/:id/channels', auth.authMiddleware, auth.requireRole(['owner', 'admin']), function(req, res) {
  var db = req.app.get('db');
  var name = xss((req.body.name || '').trim().toLowerCase().replace(/\s+/g, '-'));
  var type = req.body.type === 'voice' ? 'voice' : 'text';
  if (!name || name.length > 50) return res.status(400).json({ error: 'Channel name required (max 50)' });

  var id = uuid.v4();
  db.channels.count({ serverId: req.params.id }).then(function(count) {
    return db.channels.insert({
      _id: id, serverId: req.params.id, name: name, type: type,
      position: count, createdAt: new Date().toISOString()
    });
  }).then(function(ch) {
    var channel = { id: ch._id, server_id: ch.serverId, name: ch.name, type: ch.type, position: ch.position };
    var io = req.app.get('io');
    io.to('server:' + req.params.id).emit('channel-created', { channel: channel });
    res.json({ channel: channel });
  }).catch(function() {
    res.status(500).json({ error: 'Failed to create channel' });
  });
});

// DELETE /api/servers/:id/channels/:channelId
router.delete('/:id/channels/:channelId', auth.authMiddleware, auth.requireRole(['owner', 'admin']), function(req, res) {
  var db = req.app.get('db');
  db.messages.remove({ channelId: req.params.channelId }, { multi: true }).then(function() {
    return db.channels.remove({ _id: req.params.channelId, serverId: req.params.id });
  }).then(function() {
    var io = req.app.get('io');
    io.to('server:' + req.params.id).emit('channel-deleted', { channelId: req.params.channelId, serverId: req.params.id });
    res.json({ success: true });
  });
});

module.exports = router;
