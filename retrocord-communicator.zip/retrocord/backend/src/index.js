// backend/src/index.js
var express = require('express');
var http = require('http');
var socketIO = require('socket.io');
var cors = require('cors');
var helmet = require('helmet');
var path = require('path');
var rateLimit = require('express-rate-limit');

var db = require('./models/database');
var authRoutes = require('./routes/auth');
var serverRoutes = require('./routes/servers');
var channelRoutes = require('./routes/channels');
var messageRoutes = require('./routes/messages');
var uploadRoutes = require('./routes/upload');
var moderationRoutes = require('./routes/moderation');
var setupSocket = require('./socket/handler');

var app = express();
var server = http.createServer(app);
var io = socketIO(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
  transports: ['websocket', 'polling']
});

var PORT = process.env.PORT || 3001;
var JWT_SECRET = process.env.JWT_SECRET || 'retrocord-secret-change-me-in-production';

// Middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: '*', credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

app.use('/api/', rateLimit({ windowMs: 60000, max: 200, message: { error: 'Too many requests' } }));

// Inject dependencies
app.set('db', db);
app.set('io', io);
app.set('jwt_secret', JWT_SECRET);

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/servers', serverRoutes);
app.use('/api/servers', channelRoutes);
app.use('/api/channels', messageRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/servers', moderationRoutes);

// Serve uploads
app.use('/files', express.static(path.join(__dirname, '..', 'uploads')));

// Serve frontend
var frontendPath = path.join(__dirname, '..', '..', 'frontend', 'dist');
app.use(express.static(frontendPath));
app.get('*', function(req, res) {
  res.sendFile(path.join(frontendPath, 'index.html'));
});

// Socket.io
setupSocket(io, db, JWT_SECRET);

server.listen(PORT, function() {
  console.log('');
  console.log('  +======================================+');
  console.log('  |     RetroCord Communicator v1.0      |');
  console.log('  |     http://localhost:' + PORT + '           |');
  console.log('  +======================================+');
  console.log('');
});
