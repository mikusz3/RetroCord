// backend/src/models/database.js
// Using NeDB - pure JavaScript embedded database (no native compilation)
// MongoDB-like API, file-persisted, perfect for XP
var Datastore = require('nedb-promises');
var path = require('path');

var DB_DIR = path.join(__dirname, '..', '..', 'data');

// Ensure data directory exists
var fs = require('fs');
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

var db = {
  users: Datastore.create({ filename: path.join(DB_DIR, 'users.db'), autoload: true }),
  servers: Datastore.create({ filename: path.join(DB_DIR, 'servers.db'), autoload: true }),
  members: Datastore.create({ filename: path.join(DB_DIR, 'members.db'), autoload: true }),
  channels: Datastore.create({ filename: path.join(DB_DIR, 'channels.db'), autoload: true }),
  messages: Datastore.create({ filename: path.join(DB_DIR, 'messages.db'), autoload: true })
};

// Create indexes
db.users.ensureIndex({ fieldName: 'email', unique: true });
db.users.ensureIndex({ fieldName: 'username', unique: true });
db.servers.ensureIndex({ fieldName: 'inviteCode', unique: true, sparse: true });
db.members.ensureIndex({ fieldName: 'serverId' });
db.members.ensureIndex({ fieldName: 'userId' });
db.channels.ensureIndex({ fieldName: 'serverId' });
db.messages.ensureIndex({ fieldName: 'channelId' });
db.messages.ensureIndex({ fieldName: 'createdAt' });

console.log('[DB] NeDB initialized at ' + DB_DIR);

module.exports = db;
