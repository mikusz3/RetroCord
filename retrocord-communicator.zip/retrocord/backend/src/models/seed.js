// backend/src/models/seed.js
var db = require('./database');
var bcrypt = require('bcryptjs');
var uuid = require('uuid');

var hash = bcrypt.hashSync('password123', 10);
var user1Id = uuid.v4(), user2Id = uuid.v4(), user3Id = uuid.v4();
var serverId = uuid.v4(), ch1Id = uuid.v4(), ch2Id = uuid.v4(), ch3Id = uuid.v4();
var inviteCode = 'RETRO1';
var now = new Date().toISOString();

console.log('[SEED] Creating sample data...');

Promise.all([
  db.users.insert({ _id: user1Id, username: 'Admin', email: 'admin@retrocord.local', passwordHash: hash, avatar: null, status: 'offline', createdAt: now }),
  db.users.insert({ _id: user2Id, username: 'RetroFan', email: 'retro@retrocord.local', passwordHash: hash, avatar: null, status: 'offline', createdAt: now }),
  db.users.insert({ _id: user3Id, username: 'XPLover', email: 'xp@retrocord.local', passwordHash: hash, avatar: null, status: 'offline', createdAt: now })
]).then(function() {
  return db.servers.insert({ _id: serverId, name: 'Retro Lounge', icon: null, ownerId: user1Id, inviteCode: inviteCode, createdAt: now });
}).then(function() {
  return Promise.all([
    db.members.insert({ _id: uuid.v4(), serverId: serverId, userId: user1Id, role: 'owner', joinedAt: now }),
    db.members.insert({ _id: uuid.v4(), serverId: serverId, userId: user2Id, role: 'admin', joinedAt: now }),
    db.members.insert({ _id: uuid.v4(), serverId: serverId, userId: user3Id, role: 'member', joinedAt: now }),
    db.channels.insert({ _id: ch1Id, serverId: serverId, name: 'general', type: 'text', position: 0, createdAt: now }),
    db.channels.insert({ _id: ch2Id, serverId: serverId, name: 'random', type: 'text', position: 1, createdAt: now }),
    db.channels.insert({ _id: ch3Id, serverId: serverId, name: 'Voice Lounge', type: 'voice', position: 2, createdAt: now })
  ]);
}).then(function() {
  return Promise.all([
    db.messages.insert({ _id: uuid.v4(), channelId: ch1Id, userId: user1Id, content: 'Welcome to RetroCord!', attachments: null, createdAt: new Date(Date.now() - 5000).toISOString() }),
    db.messages.insert({ _id: uuid.v4(), channelId: ch1Id, userId: user2Id, content: 'This feels like 2004 and I love it', attachments: null, createdAt: new Date(Date.now() - 4000).toISOString() }),
    db.messages.insert({ _id: uuid.v4(), channelId: ch1Id, userId: user3Id, content: 'Running this on my ThinkPad T42!', attachments: null, createdAt: new Date(Date.now() - 3000).toISOString() })
  ]);
}).then(function() {
  console.log('[SEED] Done! Invite code: ' + inviteCode);
  console.log('[SEED] Accounts (password123): admin@retrocord.local / retro@retrocord.local / xp@retrocord.local');
  process.exit(0);
}).catch(function(err) { console.error('[SEED] Error:', err); process.exit(1); });
