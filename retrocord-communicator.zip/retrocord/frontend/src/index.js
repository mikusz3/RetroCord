// frontend/src/index.js
require('./styles/main.css');

var api = require('./utils/api');
var bus = require('./utils/events');
var san = require('./utils/sanitize');
var io = require('socket.io-client');

// ─── App State ───────────────────────────────────────────────
var state = {
  user: null,
  servers: [],
  currentServer: null,
  channels: [],
  currentChannel: null,
  messages: [],
  members: [],
  typingUsers: {},
  voiceStates: {},   // { channelId: [{ userId, username }] }
  socket: null
};

var typingTimer = null;
var scrollLocked = true;

// ─── Entry Point ─────────────────────────────────────────────
function init() {
  var token = api.getToken();
  if (token) {
    api.get('/auth/me').then(function(data) {
      state.user = data.user;
      connectSocket();
      loadServers();
      renderApp();
    }).catch(function() {
      api.clearToken();
      renderAuth();
    });
  } else {
    renderAuth();
  }
}

// ─── Socket Connection ──────────────────────────────────────
function connectSocket() {
  if (state.socket) state.socket.disconnect();

  var socket = io(window.location.origin, {
    query: { token: api.getToken() },
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionAttempts: 50
  });

  socket.on('connect', function() {
    console.log('[Socket] Connected');
    // Rejoin server rooms
    state.servers.forEach(function(s) {
      socket.emit('join-server', { serverId: s.id });
    });
    if (state.currentChannel) {
      socket.emit('join-channel', { channelId: state.currentChannel.id });
    }
  });

  socket.on('new-message', function(msg) {
    if (state.currentChannel && msg.channel_id === state.currentChannel.id) {
      state.messages.push(msg);
      renderMessages();
      if (scrollLocked) scrollToBottom();
    }
  });

  socket.on('message-deleted', function(data) {
    if (state.currentChannel && data.channelId === state.currentChannel.id) {
      state.messages = state.messages.filter(function(m) { return m.id !== data.messageId; });
      renderMessages();
    }
  });

  socket.on('user-typing', function(data) {
    if (state.currentChannel && data.channelId === state.currentChannel.id) {
      state.typingUsers[data.userId] = { username: data.username, time: Date.now() };
      renderTyping();
      // Clear after 4s
      setTimeout(function() {
        if (state.typingUsers[data.userId] && Date.now() - state.typingUsers[data.userId].time >= 3500) {
          delete state.typingUsers[data.userId];
          renderTyping();
        }
      }, 4000);
    }
  });

  socket.on('presence-update', function(data) {
    state.members.forEach(function(m) {
      if (m.id === data.userId) m.status = data.status;
    });
    renderMembers();
  });

  socket.on('member-joined', function(data) {
    if (state.currentServer && data.serverId === state.currentServer.id) {
      loadMembers(state.currentServer.id);
    }
  });

  socket.on('member-left', function(data) {
    if (state.currentServer && data.serverId === state.currentServer.id) {
      state.members = state.members.filter(function(m) { return m.id !== data.userId; });
      renderMembers();
    }
  });

  socket.on('voice-state', function(data) {
    state.voiceStates[data.channelId] = data.users;
    renderChannels();
  });

  socket.on('channel-created', function(data) {
    if (state.currentServer && data.channel.server_id === state.currentServer.id) {
      state.channels.push(data.channel);
      renderChannels();
    }
  });

  socket.on('channel-deleted', function(data) {
    if (state.currentServer && data.serverId === state.currentServer.id) {
      state.channels = state.channels.filter(function(c) { return c.id !== data.channelId; });
      if (state.currentChannel && state.currentChannel.id === data.channelId) {
        state.currentChannel = state.channels[0] || null;
        if (state.currentChannel) selectChannel(state.currentChannel);
      }
      renderChannels();
    }
  });

  socket.on('kicked-from-server', function(data) {
    if (state.currentServer && state.currentServer.id === data.serverId) {
      state.currentServer = null;
      state.currentChannel = null;
    }
    state.servers = state.servers.filter(function(s) { return s.id !== data.serverId; });
    renderApp();
  });

  socket.on('member-role-changed', function(data) {
    if (state.currentServer && data.serverId === state.currentServer.id) {
      loadMembers(state.currentServer.id);
    }
  });

  socket.on('disconnect', function() {
    console.log('[Socket] Disconnected');
  });

  state.socket = socket;
}

// ─── Data Loading ───────────────────────────────────────────
function loadServers() {
  api.get('/servers').then(function(data) {
    state.servers = data.servers || [];
    renderServerBar();
    // Join all server rooms
    state.servers.forEach(function(s) {
      if (state.socket) state.socket.emit('join-server', { serverId: s.id });
    });
  });
}

function selectServer(server) {
  state.currentServer = server;
  state.currentChannel = null;
  state.messages = [];
  state.members = [];
  state.typingUsers = {};

  renderServerBar();
  renderChatPane();
  renderMembers();

  // Load channels
  api.get('/servers/' + server.id + '/channels').then(function(data) {
    state.channels = data.channels || [];
    renderChannels();
    // Auto-select first text channel
    var textCh = state.channels.filter(function(c) { return c.type === 'text'; });
    if (textCh.length > 0) selectChannel(textCh[0]);
  });

  // Load members
  loadMembers(server.id);
}

function loadMembers(serverId) {
  api.get('/servers/' + serverId + '/members').then(function(data) {
    state.members = data.members || [];
    renderMembers();
  });
}

function selectChannel(channel) {
  // Leave previous channel
  if (state.currentChannel && state.socket) {
    state.socket.emit('leave-channel', { channelId: state.currentChannel.id });
  }

  state.currentChannel = channel;
  state.messages = [];
  state.typingUsers = {};
  scrollLocked = true;

  renderChannels();

  if (channel.type === 'voice') {
    renderVoiceChannel();
    return;
  }

  // Join channel room
  if (state.socket) {
    state.socket.emit('join-channel', { channelId: channel.id });
  }

  // Load message history
  api.get('/channels/' + channel.id + '/messages?limit=50').then(function(data) {
    state.messages = data.messages || [];
    renderChatPane();
    scrollToBottom();
  });
}

// ─── Auth Rendering ─────────────────────────────────────────
function renderAuth(mode) {
  mode = mode || 'login';
  var app = document.getElementById('app');

  var html = '<div class="auth-container">' +
    '<div class="auth-box">' +
    '<div class="logo-text">⚡ RetroCord</div>' +
    '<h1>' + (mode === 'login' ? 'Welcome back!' : 'Create an account') + '</h1>' +
    '<p class="subtitle">' + (mode === 'login' ? 'Sign in to your communicator' : 'Join the retro revolution') + '</p>' +
    '<div id="auth-error" class="error-text" style="display:none"></div>';

  if (mode === 'register') {
    html += '<div class="form-group"><label>Username</label>' +
      '<input type="text" id="auth-username" placeholder="Choose a username" maxlength="32"></div>';
  }

  html += '<div class="form-group"><label>Email</label>' +
    '<input type="email" id="auth-email" placeholder="your@email.com"></div>' +
    '<div class="form-group"><label>Password</label>' +
    '<input type="password" id="auth-password" placeholder="' + (mode === 'register' ? 'Min 6 characters' : 'Your password') + '"></div>' +
    '<button class="btn btn-primary btn-block" id="auth-submit">' +
    (mode === 'login' ? 'Log In' : 'Register') + '</button>' +
    '<div class="auth-switch">' +
    (mode === 'login'
      ? 'Need an account? <a href="#" id="auth-toggle">Register</a>'
      : 'Already have one? <a href="#" id="auth-toggle">Log In</a>') +
    '</div></div></div>';

  app.innerHTML = html;

  // Event handlers
  document.getElementById('auth-toggle').onclick = function(e) {
    e.preventDefault();
    renderAuth(mode === 'login' ? 'register' : 'login');
  };

  document.getElementById('auth-submit').onclick = function() { handleAuth(mode); };

  // Enter key support
  var pwField = document.getElementById('auth-password');
  pwField.onkeydown = function(e) {
    if (e.key === 'Enter' || e.keyCode === 13) handleAuth(mode);
  };
}

function handleAuth(mode) {
  var email = document.getElementById('auth-email').value.trim();
  var password = document.getElementById('auth-password').value;
  var errorEl = document.getElementById('auth-error');

  var body = { email: email, password: password };
  if (mode === 'register') {
    body.username = document.getElementById('auth-username').value.trim();
    if (!body.username) {
      errorEl.textContent = 'Username is required';
      errorEl.style.display = 'block';
      return;
    }
  }

  var endpoint = mode === 'login' ? '/auth/login' : '/auth/register';

  api.post(endpoint, body).then(function(data) {
    api.setToken(data.token);
    state.user = data.user;
    connectSocket();
    loadServers();
    renderApp();
  }).catch(function(err) {
    errorEl.textContent = err.message || 'Something went wrong';
    errorEl.style.display = 'block';
  });
}

// ─── Main App Rendering ─────────────────────────────────────
function renderApp() {
  var app = document.getElementById('app');
  app.innerHTML =
    '<div class="app-layout">' +
    '  <div class="server-bar" id="server-bar"></div>' +
    '  <div class="channel-sidebar" id="channel-sidebar">' +
    '    <div class="channel-sidebar-header" id="channel-header"></div>' +
    '    <div class="channel-list" id="channel-list"></div>' +
    '    <div class="user-area" id="user-area"></div>' +
    '  </div>' +
    '  <div class="chat-pane" id="chat-pane"></div>' +
    '  <div class="member-sidebar" id="member-sidebar"></div>' +
    '</div>' +
    '<div id="modal-container"></div>';

  renderServerBar();
  renderUserArea();

  if (state.currentServer) {
    selectServer(state.currentServer);
  } else if (state.servers.length > 0) {
    selectServer(state.servers[0]);
  } else {
    renderWelcome();
  }
}

// ─── Server Bar ─────────────────────────────────────────────
function renderServerBar() {
  var el = document.getElementById('server-bar');
  if (!el) return;

  var html = '';
  state.servers.forEach(function(s) {
    var isActive = state.currentServer && state.currentServer.id === s.id;
    var initials = san.getInitials(s.name);
    html += '<div class="server-icon' + (isActive ? ' active' : '') + '" ' +
      'data-server-id="' + s.id + '" title="' + san.escapeHtml(s.name) + '">' +
      initials + '</div>';
  });

  html += '<div class="server-divider"></div>';
  html += '<div class="server-icon server-add" id="btn-add-server" title="Create or Join Server">+</div>';

  el.innerHTML = html;

  // Click handlers
  var icons = el.querySelectorAll('.server-icon[data-server-id]');
  for (var i = 0; i < icons.length; i++) {
    icons[i].onclick = (function(icon) {
      return function() {
        var sid = icon.getAttribute('data-server-id');
        var server = state.servers.filter(function(s) { return s.id === sid; })[0];
        if (server) selectServer(server);
      };
    })(icons[i]);
  }

  var addBtn = document.getElementById('btn-add-server');
  if (addBtn) addBtn.onclick = showServerModal;
}

// ─── Channel Sidebar ────────────────────────────────────────
function renderChannels() {
  var headerEl = document.getElementById('channel-header');
  var listEl = document.getElementById('channel-list');
  if (!headerEl || !listEl) return;

  if (!state.currentServer) {
    headerEl.innerHTML = '<h2>RetroCord</h2>';
    listEl.innerHTML = '';
    return;
  }

  var s = state.currentServer;
  var role = s.my_role || 'member';
  var canManage = role === 'owner' || role === 'admin';

  headerEl.innerHTML = '<h2>' + san.escapeHtml(s.name) + '</h2>' +
    (canManage ? '<button class="btn btn-small btn-secondary" id="btn-server-settings" title="Settings">⚙</button>' : '');

  if (document.getElementById('btn-server-settings')) {
    document.getElementById('btn-server-settings').onclick = showServerSettings;
  }

  // Separate text and voice channels
  var textChs = state.channels.filter(function(c) { return c.type === 'text'; });
  var voiceChs = state.channels.filter(function(c) { return c.type === 'voice'; });

  var html = '';

  // Text channels
  html += '<div class="channel-category">Text Channels' +
    (canManage ? ' <span style="cursor:pointer;color:var(--accent)" id="btn-add-text-ch" title="Add channel">+</span>' : '') +
    '</div>';
  textChs.forEach(function(ch) {
    var isActive = state.currentChannel && state.currentChannel.id === ch.id;
    html += '<div class="channel-item' + (isActive ? ' active' : '') + '" data-ch-id="' + ch.id + '">' +
      '<span class="channel-hash">#</span> ' + san.escapeHtml(ch.name) + '</div>';
  });

  // Voice channels
  html += '<div class="channel-category">Voice Channels' +
    (canManage ? ' <span style="cursor:pointer;color:var(--accent)" id="btn-add-voice-ch" title="Add voice channel">+</span>' : '') +
    '</div>';
  voiceChs.forEach(function(ch) {
    var isActive = state.currentChannel && state.currentChannel.id === ch.id;
    var voiceUsers = state.voiceStates[ch.id] || [];
    html += '<div class="channel-item voice' + (isActive ? ' active' : '') + '" data-ch-id="' + ch.id + '">' +
      '<span class="channel-hash">🔊</span> ' + san.escapeHtml(ch.name) + '</div>';
    // Show users in voice
    if (voiceUsers.length > 0) {
      html += '<div class="voice-users">';
      voiceUsers.forEach(function(u) {
        html += '<div class="voice-user"><span class="status-dot"></span>' + san.escapeHtml(u.username) + '</div>';
      });
      html += '</div>';
    }
  });

  listEl.innerHTML = html;

  // Channel click handlers
  var chItems = listEl.querySelectorAll('.channel-item[data-ch-id]');
  for (var i = 0; i < chItems.length; i++) {
    chItems[i].onclick = (function(item) {
      return function() {
        var chId = item.getAttribute('data-ch-id');
        var ch = state.channels.filter(function(c) { return c.id === chId; })[0];
        if (ch) selectChannel(ch);
      };
    })(chItems[i]);
  }

  // Add channel buttons
  var addTextBtn = document.getElementById('btn-add-text-ch');
  if (addTextBtn) addTextBtn.onclick = function(e) { e.stopPropagation(); showAddChannelModal('text'); };
  var addVoiceBtn = document.getElementById('btn-add-voice-ch');
  if (addVoiceBtn) addVoiceBtn.onclick = function(e) { e.stopPropagation(); showAddChannelModal('voice'); };
}

function renderUserArea() {
  var el = document.getElementById('user-area');
  if (!el || !state.user) return;

  el.innerHTML =
    '<div class="user-avatar-small" style="background:' + san.stringColor(state.user.username) + '">' +
    san.getInitials(state.user.username) + '</div>' +
    '<div class="user-info">' +
    '<div class="username">' + san.escapeHtml(state.user.username) + '</div>' +
    '<div class="user-status">Online</div>' +
    '</div>' +
    '<button class="btn-logout" id="btn-logout" title="Log out">⏻</button>';

  document.getElementById('btn-logout').onclick = function() {
    api.post('/auth/logout').catch(function() {});
    api.clearToken();
    if (state.socket) state.socket.disconnect();
    state.user = null;
    state.servers = [];
    state.currentServer = null;
    renderAuth();
  };
}

// ─── Chat Pane ──────────────────────────────────────────────
function renderChatPane() {
  var el = document.getElementById('chat-pane');
  if (!el) return;

  if (!state.currentChannel || state.currentChannel.type === 'voice') {
    if (state.currentChannel && state.currentChannel.type === 'voice') {
      renderVoiceChannel();
    } else {
      renderWelcome();
    }
    return;
  }

  el.innerHTML =
    '<div class="chat-header">' +
    '  <div class="channel-name"><span class="hash">#</span>' + san.escapeHtml(state.currentChannel.name) + '</div>' +
    '</div>' +
    '<div class="chat-messages" id="chat-messages"><div class="messages-start"></div></div>' +
    '<div class="typing-indicator" id="typing-indicator"></div>' +
    '<div class="chat-input-area">' +
    '  <div class="chat-input-wrap">' +
    '    <input type="text" id="message-input" placeholder="Message #' + san.escapeHtml(state.currentChannel.name) + '" maxlength="2000" autocomplete="off">' +
    '    <label class="btn-upload" title="Upload file">📎<input type="file" id="file-input" style="display:none"></label>' +
    '    <button class="btn-send" id="btn-send">Send</button>' +
    '  </div>' +
    '</div>';

  renderMessages();

  // Message send handler
  var msgInput = document.getElementById('message-input');
  var sendBtn = document.getElementById('btn-send');
  var fileInput = document.getElementById('file-input');

  function sendMessage() {
    var content = msgInput.value.trim();
    if (!content) return;
    if (state.socket && state.currentChannel) {
      state.socket.emit('send-message', {
        channelId: state.currentChannel.id,
        content: content
      });
    }
    msgInput.value = '';
  }

  sendBtn.onclick = sendMessage;
  msgInput.onkeydown = function(e) {
    if (e.key === 'Enter' || e.keyCode === 13) {
      e.preventDefault();
      sendMessage();
    } else {
      // Typing indicator
      if (state.socket && state.currentChannel) {
        if (!typingTimer) {
          state.socket.emit('typing', { channelId: state.currentChannel.id });
          typingTimer = setTimeout(function() { typingTimer = null; }, 3000);
        }
      }
    }
  };

  // File upload
  fileInput.onchange = function() {
    if (fileInput.files.length > 0) {
      api.uploadFile(fileInput.files[0]).then(function(data) {
        // Send as message with attachment
        if (state.socket && state.currentChannel) {
          var content = data.filename + ' ' + data.url;
          // If image, the URL will auto-embed via formatMessage
          if (/\.(jpg|jpeg|png|gif|bmp|webp)$/i.test(data.url)) {
            content = window.location.origin + data.url;
          }
          state.socket.emit('send-message', {
            channelId: state.currentChannel.id,
            content: content,
            attachments: [data]
          });
        }
        fileInput.value = '';
      }).catch(function(err) {
        alert(err.message || 'Upload failed');
      });
    }
  };

  // Scroll detection
  var chatMsgs = document.getElementById('chat-messages');
  chatMsgs.onscroll = function() {
    var el = chatMsgs;
    scrollLocked = (el.scrollHeight - el.scrollTop - el.clientHeight) < 60;
  };
}

function renderMessages() {
  var container = document.getElementById('chat-messages');
  if (!container) return;

  var html = '<div class="messages-start"></div>';
  var prevUserId = null;
  var prevDate = null;

  state.messages.forEach(function(msg) {
    var showHeader = msg.user_id !== prevUserId;
    var color = san.stringColor(msg.username || 'Unknown');
    var canDelete = state.user && (msg.user_id === state.user.id);
    // Also check if user is admin/owner
    if (state.currentServer && !canDelete) {
      var role = state.currentServer.my_role;
      canDelete = role === 'owner' || role === 'admin';
    }

    html += '<div class="message" data-msg-id="' + msg.id + '">';

    if (showHeader) {
      html += '<div class="msg-avatar" style="background:' + color + '">' +
        san.getInitials(msg.username || '?') + '</div>';
    } else {
      html += '<div class="msg-avatar" style="visibility:hidden"></div>';
    }

    html += '<div class="msg-body">';
    if (showHeader) {
      html += '<div class="msg-header">' +
        '<span class="msg-username" style="color:' + color + '">' + san.escapeHtml(msg.username || 'Unknown') + '</span>' +
        '<span class="msg-time">' + san.formatTime(msg.created_at) + '</span>' +
        '</div>';
    }
    html += '<div class="msg-content">' + san.formatMessage(msg.content) + '</div>';

    if (canDelete) {
      html += '<div class="msg-actions"><button class="btn-delete-msg" data-msg-id="' + msg.id + '" title="Delete">🗑</button></div>';
    }

    html += '</div></div>';

    prevUserId = msg.user_id;
  });

  container.innerHTML = html;

  // Delete handlers
  var delBtns = container.querySelectorAll('.btn-delete-msg');
  for (var i = 0; i < delBtns.length; i++) {
    delBtns[i].onclick = (function(btn) {
      return function() {
        var msgId = btn.getAttribute('data-msg-id');
        if (confirm('Delete this message?')) {
          api.del('/channels/messages/' + msgId).catch(function(err) {
            alert(err.message || 'Failed to delete');
          });
        }
      };
    })(delBtns[i]);
  }
}

function renderTyping() {
  var el = document.getElementById('typing-indicator');
  if (!el) return;
  var names = [];
  for (var uid in state.typingUsers) {
    if (uid !== state.user.id) {
      names.push(state.typingUsers[uid].username);
    }
  }
  if (names.length === 0) {
    el.textContent = '';
  } else if (names.length === 1) {
    el.textContent = names[0] + ' is typing...';
  } else {
    el.textContent = names.join(', ') + ' are typing...';
  }
}

function scrollToBottom() {
  var el = document.getElementById('chat-messages');
  if (el) {
    setTimeout(function() { el.scrollTop = el.scrollHeight; }, 50);
  }
}

// ─── Voice Channel View ─────────────────────────────────────
function renderVoiceChannel() {
  var el = document.getElementById('chat-pane');
  if (!el || !state.currentChannel) return;

  var ch = state.currentChannel;
  var voiceUsers = state.voiceStates[ch.id] || [];
  var amInVoice = voiceUsers.some(function(u) { return u.userId === state.user.id; });

  // Check WebRTC support
  var hasWebRTC = !!(window.RTCPeerConnection || window.webkitRTCPeerConnection || window.mozRTCPeerConnection);

  var html =
    '<div class="chat-header">' +
    '  <div class="channel-name"><span class="hash">🔊</span>' + san.escapeHtml(ch.name) + '</div>' +
    '</div>' +
    '<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px">' +
    '  <h2 style="color:var(--accent);margin-bottom:12px">🔊 ' + san.escapeHtml(ch.name) + '</h2>';

  if (!hasWebRTC) {
    html += '<p style="color:var(--warning);margin-bottom:16px;text-align:center">' +
      '⚠️ Your browser doesn\'t support WebRTC. You can join the room to see who\'s here, but voice chat won\'t work.</p>';
  }

  html += '<p style="color:var(--text-secondary);margin-bottom:20px">' +
    voiceUsers.length + ' user' + (voiceUsers.length !== 1 ? 's' : '') + ' in channel</p>';

  // Show users in voice
  if (voiceUsers.length > 0) {
    html += '<div style="margin-bottom:20px">';
    voiceUsers.forEach(function(u) {
      var color = san.stringColor(u.username);
      html += '<div style="display:flex;align-items:center;padding:6px 16px;margin:2px 0;background:var(--bg-dark);border-radius:6px">' +
        '<div class="user-avatar-small" style="background:' + color + ';width:28px;height:28px;font-size:12px;margin-right:10px">' +
        san.getInitials(u.username) + '</div>' +
        '<span style="color:var(--text-primary)">' + san.escapeHtml(u.username) + '</span>' +
        (u.userId === state.user.id ? '<span style="color:var(--text-muted);margin-left:8px;font-size:12px">(you)</span>' : '') +
        '</div>';
    });
    html += '</div>';
  }

  if (amInVoice) {
    html += '<button class="btn btn-danger" id="btn-leave-voice">Leave Voice Channel</button>';
  } else {
    html += '<button class="btn btn-primary" id="btn-join-voice">' +
      (hasWebRTC ? 'Join Voice' : 'Join Room (text-only)') + '</button>';
  }

  html += '</div>';
  el.innerHTML = html;

  var joinBtn = document.getElementById('btn-join-voice');
  var leaveBtn = document.getElementById('btn-leave-voice');

  if (joinBtn) {
    joinBtn.onclick = function() {
      if (state.socket) state.socket.emit('join-voice', { channelId: ch.id });
    };
  }
  if (leaveBtn) {
    leaveBtn.onclick = function() {
      if (state.socket) state.socket.emit('leave-voice', { channelId: ch.id });
    };
  }
}

// ─── Member Sidebar ─────────────────────────────────────────
function renderMembers() {
  var el = document.getElementById('member-sidebar');
  if (!el) return;

  if (!state.currentServer) {
    el.innerHTML = '';
    return;
  }

  var online = state.members.filter(function(m) { return m.status === 'online'; });
  var offline = state.members.filter(function(m) { return m.status !== 'online'; });

  var html = '';

  if (online.length > 0) {
    html += '<h3>Online — ' + online.length + '</h3>';
    online.forEach(function(m) { html += memberHtml(m, true); });
  }
  if (offline.length > 0) {
    html += '<h3>Offline — ' + offline.length + '</h3>';
    offline.forEach(function(m) { html += memberHtml(m, false); });
  }

  el.innerHTML = html;

  // Right-click context for moderation
  var items = el.querySelectorAll('.member-item');
  for (var i = 0; i < items.length; i++) {
    items[i].oncontextmenu = (function(item) {
      return function(e) {
        e.preventDefault();
        var uid = item.getAttribute('data-uid');
        showMemberContextMenu(e, uid);
      };
    })(items[i]);
  }
}

function memberHtml(m, isOnline) {
  var color = san.stringColor(m.username);
  var badgeHtml = '';
  if (m.role === 'owner') badgeHtml = '<span class="member-role-badge badge-owner">OWNER</span>';
  else if (m.role === 'admin') badgeHtml = '<span class="member-role-badge badge-admin">ADMIN</span>';

  return '<div class="member-item" data-uid="' + m.id + '">' +
    '<div class="member-avatar" style="background:' + color + '">' +
    san.getInitials(m.username) +
    '<span class="presence-dot ' + (isOnline ? 'online' : 'offline') + '"></span>' +
    '</div>' +
    '<span class="member-name' + (isOnline ? ' is-online' : '') + '">' +
    san.escapeHtml(m.username) + '</span>' + badgeHtml + '</div>';
}

// ─── Welcome Pane ───────────────────────────────────────────
function renderWelcome() {
  var chatEl = document.getElementById('chat-pane');
  if (!chatEl) return;

  chatEl.innerHTML =
    '<div class="welcome-pane">' +
    '<h2>⚡ RetroCord</h2>' +
    '<p>Create a server to start chatting, or join one with an invite code.</p>' +
    '<div style="display:flex;gap:8px">' +
    '<button class="btn btn-primary" id="btn-welcome-create">Create Server</button>' +
    '<button class="btn btn-secondary" id="btn-welcome-join">Join Server</button>' +
    '</div></div>';

  document.getElementById('btn-welcome-create').onclick = function() { showServerModal('create'); };
  document.getElementById('btn-welcome-join').onclick = function() { showServerModal('join'); };

  // Clear members
  var memEl = document.getElementById('member-sidebar');
  if (memEl) memEl.innerHTML = '';
}

// ─── Modals ─────────────────────────────────────────────────
function showModal(title, bodyHtml, onSubmit) {
  var container = document.getElementById('modal-container');
  if (!container) return;

  container.innerHTML =
    '<div class="modal-overlay" id="modal-overlay">' +
    '<div class="modal">' +
    '<h2>' + san.escapeHtml(title) + '</h2>' +
    '<div id="modal-error" class="error-text" style="display:none"></div>' +
    bodyHtml +
    '<div class="modal-actions">' +
    '<button class="btn btn-secondary" id="modal-cancel">Cancel</button>' +
    '<button class="btn btn-primary" id="modal-submit">Confirm</button>' +
    '</div></div></div>';

  document.getElementById('modal-cancel').onclick = closeModal;
  document.getElementById('modal-overlay').onclick = function(e) {
    if (e.target.id === 'modal-overlay') closeModal();
  };
  document.getElementById('modal-submit').onclick = function() {
    if (onSubmit) onSubmit();
  };
}

function closeModal() {
  var container = document.getElementById('modal-container');
  if (container) container.innerHTML = '';
}

function showServerModal(defaultTab) {
  var body =
    '<div style="display:flex;gap:8px;margin-bottom:16px">' +
    '<button class="btn btn-small" id="tab-create" style="flex:1">Create</button>' +
    '<button class="btn btn-small" id="tab-join" style="flex:1">Join</button>' +
    '</div>' +
    '<div id="modal-tab-content"></div>';

  showModal('Add a Server', body, null);

  var tabCreate = document.getElementById('tab-create');
  var tabJoin = document.getElementById('tab-join');

  function showCreateTab() {
    tabCreate.className = 'btn btn-small btn-primary';
    tabJoin.className = 'btn btn-small btn-secondary';
    document.getElementById('modal-tab-content').innerHTML =
      '<div class="form-group"><label>Server Name</label>' +
      '<input type="text" id="new-server-name" placeholder="My Awesome Server" maxlength="100"></div>';
    document.getElementById('modal-submit').onclick = function() {
      var name = document.getElementById('new-server-name').value.trim();
      if (!name) return;
      api.post('/servers', { name: name }).then(function(data) {
        closeModal();
        loadServers();
        // Select the new server
        setTimeout(function() {
          state.currentServer = data.server;
          selectServer(data.server);
        }, 300);
      }).catch(function(err) {
        var errEl = document.getElementById('modal-error');
        errEl.textContent = err.message;
        errEl.style.display = 'block';
      });
    };
  }

  function showJoinTab() {
    tabCreate.className = 'btn btn-small btn-secondary';
    tabJoin.className = 'btn btn-small btn-primary';
    document.getElementById('modal-tab-content').innerHTML =
      '<div class="form-group"><label>Invite Code</label>' +
      '<input type="text" id="invite-code-input" placeholder="ABC123" style="text-transform:uppercase"></div>';
    document.getElementById('modal-submit').onclick = function() {
      var code = document.getElementById('invite-code-input').value.trim();
      if (!code) return;
      api.post('/servers/join', { inviteCode: code }).then(function(data) {
        closeModal();
        loadServers();
        setTimeout(function() { selectServer(data.server); }, 300);
      }).catch(function(err) {
        var errEl = document.getElementById('modal-error');
        errEl.textContent = err.message;
        errEl.style.display = 'block';
      });
    };
  }

  tabCreate.onclick = showCreateTab;
  tabJoin.onclick = showJoinTab;

  if (defaultTab === 'join') showJoinTab();
  else showCreateTab();
}

function showAddChannelModal(type) {
  showModal('Create ' + (type === 'voice' ? 'Voice' : 'Text') + ' Channel',
    '<div class="form-group"><label>Channel Name</label>' +
    '<input type="text" id="new-ch-name" placeholder="' + (type === 'voice' ? 'Voice Lounge' : 'general') + '" maxlength="50"></div>',
    function() {
      var name = document.getElementById('new-ch-name').value.trim();
      if (!name || !state.currentServer) return;
      api.post('/servers/' + state.currentServer.id + '/channels', { name: name, type: type })
        .then(function() { closeModal(); })
        .catch(function(err) {
          var errEl = document.getElementById('modal-error');
          errEl.textContent = err.message;
          errEl.style.display = 'block';
        });
    }
  );
}

function showServerSettings() {
  if (!state.currentServer) return;
  var s = state.currentServer;
  var isOwner = s.my_role === 'owner';

  var body = '<div class="form-group"><label>Invite Code</label>' +
    '<div class="invite-code" id="current-invite">' + (s.invite_code || '...') + '</div>' +
    '<button class="btn btn-small btn-secondary" id="btn-regen-invite" style="margin-top:4px">Regenerate Code</button></div>';

  if (isOwner) {
    body += '<div style="border-top:1px solid var(--border);padding-top:16px;margin-top:16px">' +
      '<button class="btn btn-danger btn-small" id="btn-delete-server">Delete Server</button></div>';
  }

  showModal('Server Settings', body, function() { closeModal(); });

  // Remove confirm button, replace with close
  document.getElementById('modal-submit').textContent = 'Close';

  document.getElementById('btn-regen-invite').onclick = function() {
    api.post('/servers/' + s.id + '/invite').then(function(data) {
      document.getElementById('current-invite').textContent = data.inviteCode;
      s.invite_code = data.inviteCode;
    });
  };

  if (isOwner && document.getElementById('btn-delete-server')) {
    document.getElementById('btn-delete-server').onclick = function() {
      if (confirm('Delete "' + s.name + '"? This cannot be undone!')) {
        api.del('/servers/' + s.id).then(function() {
          closeModal();
          state.currentServer = null;
          loadServers();
          renderApp();
        });
      }
    };
  }
}

// ─── Context Menu for Members ───────────────────────────────
function showMemberContextMenu(event, userId) {
  if (!state.currentServer || !state.user) return;
  var myRole = state.currentServer.my_role;
  if (myRole !== 'owner' && myRole !== 'admin') return;
  if (userId === state.user.id) return;

  // Remove existing
  var existing = document.querySelector('.context-menu');
  if (existing) existing.remove();

  var member = state.members.filter(function(m) { return m.id === userId; })[0];
  if (!member) return;

  var menu = document.createElement('div');
  menu.className = 'context-menu';
  menu.style.left = event.clientX + 'px';
  menu.style.top = event.clientY + 'px';

  var html = '';

  if (myRole === 'owner') {
    if (member.role === 'member') {
      html += '<div class="context-menu-item" data-action="promote">Promote to Admin</div>';
    } else if (member.role === 'admin') {
      html += '<div class="context-menu-item" data-action="demote">Demote to Member</div>';
    }
  }

  if (member.role !== 'owner') {
    html += '<div class="context-menu-item danger" data-action="kick">Kick User</div>';
  }

  if (!html) return;
  menu.innerHTML = html;
  document.body.appendChild(menu);

  var items = menu.querySelectorAll('.context-menu-item');
  for (var i = 0; i < items.length; i++) {
    items[i].onclick = (function(item) {
      return function() {
        var action = item.getAttribute('data-action');
        if (action === 'kick') {
          if (confirm('Kick ' + member.username + '?')) {
            api.post('/servers/' + state.currentServer.id + '/kick', { userId: userId });
          }
        } else if (action === 'promote') {
          api.post('/servers/' + state.currentServer.id + '/role', { userId: userId, role: 'admin' });
        } else if (action === 'demote') {
          api.post('/servers/' + state.currentServer.id + '/role', { userId: userId, role: 'member' });
        }
        menu.remove();
      };
    })(items[i]);
  }

  // Close on click outside
  setTimeout(function() {
    document.addEventListener('click', function closeCtx() {
      menu.remove();
      document.removeEventListener('click', closeCtx);
    });
  }, 0);
}

// ─── Start ──────────────────────────────────────────────────
init();
