// frontend/src/utils/api.js

var API_BASE = '/api';

function getToken() {
  try { return localStorage.getItem('retrocord_token') || ''; }
  catch (e) { return ''; }
}

function setToken(token) {
  try { localStorage.setItem('retrocord_token', token); }
  catch (e) {}
}

function clearToken() {
  try { localStorage.removeItem('retrocord_token'); }
  catch (e) {}
}

function request(method, path, body) {
  var opts = {
    method: method,
    headers: {
      'Content-Type': 'application/json'
    }
  };
  var token = getToken();
  if (token) opts.headers['Authorization'] = 'Bearer ' + token;
  if (body && method !== 'GET') opts.body = JSON.stringify(body);

  return fetch(API_BASE + path, opts).then(function(res) {
    return res.json().then(function(data) {
      if (!res.ok) throw { status: res.status, message: data.error || 'Request failed' };
      return data;
    });
  });
}

function uploadFile(file) {
  var formData = new FormData();
  formData.append('file', file);
  return fetch(API_BASE + '/upload', {
    method: 'POST',
    headers: { 'Authorization': 'Bearer ' + getToken() },
    body: formData
  }).then(function(res) {
    return res.json().then(function(data) {
      if (!res.ok) throw { message: data.error };
      return data;
    });
  });
}

module.exports = {
  getToken: getToken,
  setToken: setToken,
  clearToken: clearToken,
  get: function(p) { return request('GET', p); },
  post: function(p, b) { return request('POST', p, b); },
  del: function(p, b) { return request('DELETE', p, b); },
  uploadFile: uploadFile
};
