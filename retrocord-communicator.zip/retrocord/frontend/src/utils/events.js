// frontend/src/utils/events.js
// Simple event emitter for decoupled components

function EventBus() {
  this._listeners = {};
}

EventBus.prototype.on = function(event, fn) {
  if (!this._listeners[event]) this._listeners[event] = [];
  this._listeners[event].push(fn);
  return this;
};

EventBus.prototype.off = function(event, fn) {
  if (!this._listeners[event]) return this;
  this._listeners[event] = this._listeners[event].filter(function(f) { return f !== fn; });
  return this;
};

EventBus.prototype.emit = function(event, data) {
  if (!this._listeners[event]) return this;
  this._listeners[event].forEach(function(fn) {
    try { fn(data); } catch (e) { console.error('EventBus error:', e); }
  });
  return this;
};

module.exports = new EventBus();
