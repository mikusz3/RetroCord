// frontend/src/utils/sanitize.js
// Basic HTML escaping for rendering user content

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatTime(isoString) {
  try {
    var d = new Date(isoString);
    var now = new Date();
    var hours = d.getHours();
    var mins = d.getMinutes();
    var h = hours < 10 ? '0' + hours : hours;
    var m = mins < 10 ? '0' + mins : mins;

    // If today, show time only
    if (d.toDateString() === now.toDateString()) {
      return 'Today at ' + h + ':' + m;
    }
    // If yesterday
    var yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    if (d.toDateString() === yesterday.toDateString()) {
      return 'Yesterday at ' + h + ':' + m;
    }
    // Otherwise show date
    var day = d.getDate();
    var mon = d.getMonth() + 1;
    return (day < 10 ? '0' : '') + day + '/' + (mon < 10 ? '0' : '') + mon + '/' + d.getFullYear() + ' ' + h + ':' + m;
  } catch (e) {
    return isoString || '';
  }
}

// Parse message content for basic formatting: links, image embeds
function formatMessage(text) {
  text = escapeHtml(text);

  // URLs to links
  text = text.replace(
    /(https?:\/\/[^\s<]+)/g,
    function(url) {
      // Check if it's an image
      if (/\.(jpg|jpeg|png|gif|bmp|webp)(\?.*)?$/i.test(url)) {
        return '<a href="' + url + '" target="_blank">' + url + '</a>' +
          '<br><img class="msg-image" src="' + url + '" alt="image" loading="lazy">';
      }
      return '<a href="' + url + '" target="_blank">' + url + '</a>';
    }
  );

  // Newlines to <br>
  text = text.replace(/\n/g, '<br>');

  return text;
}

function getInitials(name) {
  if (!name) return '?';
  return name.charAt(0).toUpperCase();
}

// Generate a consistent color from a string
function stringColor(str) {
  var colors = ['#4db896', '#5b9bd5', '#d4a54a', '#c77dba', '#e05555', '#5bbde0', '#7dd45b'];
  var hash = 0;
  for (var i = 0; i < (str || '').length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length];
}

module.exports = {
  escapeHtml: escapeHtml,
  formatTime: formatTime,
  formatMessage: formatMessage,
  getInitials: getInitials,
  stringColor: stringColor
};
